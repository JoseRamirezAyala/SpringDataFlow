package io.spring.dataflow.sample.usagecostlogger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsageCostLoggerRabbitApplicationTests {

	@Test
	void contextLoads() {
	}

}
