package io.spring.dataflow.sample.usagecostprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsageCostProcessorRabbitApplicationTests {

	@Test
	void contextLoads() {
	}

}
