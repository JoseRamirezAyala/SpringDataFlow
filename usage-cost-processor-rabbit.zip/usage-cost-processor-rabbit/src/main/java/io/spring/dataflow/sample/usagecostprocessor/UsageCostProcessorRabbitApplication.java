package io.spring.dataflow.sample.usagecostprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsageCostProcessorRabbitApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsageCostProcessorRabbitApplication.class, args);
	}

}
