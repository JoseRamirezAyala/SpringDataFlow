package io.spring.dataflow.sample.usagedetailsender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsageDetailSenderRabbitApplicationTests {

	@Test
	void contextLoads() {
	}

}
